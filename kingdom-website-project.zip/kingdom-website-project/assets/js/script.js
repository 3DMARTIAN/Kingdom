document.getElementById("contactForm").addEventListener("submit", function(e) {
    e.preventDefault();
    alert("👑 Your royal message has been delivered!");
});
