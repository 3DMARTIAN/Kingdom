# 👑 Royal Kingdom Website

Simple static website themed about a fantasy kingdom.

## Features
- Fantasy kingdom design
- Responsive layout
- Hero section
- Contact form with JavaScript interaction
- Clean project structure

## How to Run
Open `index.html` in your browser.

## Great For
- Beginner frontend portfolio
- GitHub commit practice
- HTML, CSS, JS learning project
